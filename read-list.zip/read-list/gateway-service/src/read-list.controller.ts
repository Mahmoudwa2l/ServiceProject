import { Controller, Post, Get, Body, Param } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { CreateReadListDto } from './read-list.dto'; // Import your DTOs
import { ConfigService } from './config.service';
import { firstValueFrom } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HttpException, HttpStatus } from '@nestjs/common';

@Controller('read-list')
export class ReadListController {
  private readonly readListServiceUrl: string;

  constructor(
    private readonly httpService: HttpService,
    private readonly configService: ConfigService
  ) {
    const host = this.configService.get('READ_LIST_MICROSERVICE_HOST');
    const port = this.configService.get('READ_LIST_MICROSERVICE_PORT');
    this.readListServiceUrl = `http://${host}:${port}/read-list`;
  }

  @Post()
  async create(@Body() createReadListDto: CreateReadListDto) {
    try {
      const response = await firstValueFrom(
        this.httpService.post(this.readListServiceUrl, createReadListDto)
      );
      return response.data; // Return only the data part of the response
    } catch (error) {
      throw new HttpException('Failed to create read list', HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @Get(':id')
  async findOne(@Param('id') id: string) {
    try {
      const response = await firstValueFrom(
        this.httpService.get(`${this.readListServiceUrl}/${id}`)
      );
      return response.data; // Return only the data part of the response
    } catch (error) {
      throw new HttpException('Failed to find read list', HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  // Implement other endpoints in a similar fashion, ensuring to return response.data
}
