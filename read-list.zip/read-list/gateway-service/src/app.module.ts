import { Module } from '@nestjs/common';
import { HttpModule } from '@nestjs/axios';
import { ReadListController } from './read-list.controller';
import { ConfigService } from './config.service'; // Ensure this service is correctly implemented

@Module({
  imports: [HttpModule],
  controllers: [ReadListController],
  providers: [
    {
      provide: ConfigService,
      useValue: new ConfigService('.env'),
    },
  ],
})
export class AppModule {}
