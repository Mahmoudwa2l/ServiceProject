export class CreateReadListDto {
  readonly user: string; // Assuming user is identified by a string ID
  readonly stories: string[]; // Array of story IDs
}
export class UpdateReadListDto {
  readonly stories: string[]; // Array of story IDs for update
}
