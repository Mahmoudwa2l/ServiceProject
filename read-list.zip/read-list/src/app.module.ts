import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { MongooseModule } from '@nestjs/mongoose';
import * as dotenv from 'dotenv'; // Import dotenv
import { ConfigModule } from '@nestjs/config';
import { ReadListModule } from './read-list/read-list.module';
dotenv.config();

@Module({
  imports: [ConfigModule.forRoot(),MongooseModule.forRoot(process.env.MONGODB_URL), ReadListModule,],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
