import { Controller, Get, Post, Body, Param, Put, Delete } from '@nestjs/common';
import { ReadListService } from './read-list.service';
import { ReadList } from './read-list.model'; // Import the ReadList interface

@Controller('read-list')
export class ReadListController {
    constructor(private readonly readListService: ReadListService) {}

    @Post()
    async create(@Body() createReadListDto: ReadList): Promise<ReadList> {
        return this.readListService.create(createReadListDto);
    }

    @Get()
    async findAll(): Promise<ReadList[]> {
        return this.readListService.findAll();
    }

    @Get(':id')
    async findOne(@Param('id') id: string): Promise<ReadList> {
        return this.readListService.findOne(id);
    }

    @Put(':id')
    async update(@Param('id') id: string, @Body() updateReadListDto: ReadList): Promise<ReadList> {
        // Assuming you have an update method in your service
        return this.readListService.update(id, updateReadListDto);
    }

    @Delete(':id')
    async remove(@Param('id') id: string): Promise<any> {
        // Assuming you have a delete method in your service
        return this.readListService.delete(id);
    }

    // Additional route to count stories in a read list
    @Get(':id/count')
    async countStoriesInList(@Param('id') id: string): Promise<number> {
        return this.readListService.countStoriesInList(id);
    }
}
