import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { ReadListController } from './read-list.controller';
import { ReadListService } from './read-list.service';
import { ReadListSchema } from './read-list.model'; // Import the ReadList schema

@Module({
  imports: [
    MongooseModule.forFeature([{ name: 'ReadList', schema: ReadListSchema }]), // Provide ReadList model to Mongoose
  ],
  controllers: [ReadListController],
  providers: [ReadListService],
})
export class ReadListModule {}
