import { Schema, Document, model, Types } from 'mongoose';
// ReadList model
export interface ReadList extends Document {
    user: Types.ObjectId; // Reference to the User
    stories: Types.ObjectId[]; // List of Story references
  }
  
  export const ReadListSchema = new Schema({
    user: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    stories: [{
      type: Schema.Types.ObjectId,
      ref: 'Story'
    }]
  });
  
  export const ReadListModel = model<ReadList>('ReadList', ReadListSchema);