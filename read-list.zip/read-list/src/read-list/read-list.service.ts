import { Injectable, Inject } from '@nestjs/common';
import { Model } from 'mongoose';
import { InjectModel } from '@nestjs/mongoose';
import { ReadList } from './read-list.model'; // Import the ReadList interface

@Injectable()
export class ReadListService {
  constructor(@InjectModel('ReadList') private readonly readListModel: Model<ReadList>) {}

  async create(readList: ReadList): Promise<ReadList> {
    const newReadList = new this.readListModel(readList);
    return await newReadList.save();
  }

  async findAll(): Promise<ReadList[]> {
    return await this.readListModel.find().exec();
  }

  async findOne(id: string): Promise<ReadList> {
    return await this.readListModel.findById(id).exec();
  }

  async update(id: string, readList: ReadList): Promise<ReadList> {
    return await this.readListModel.findByIdAndUpdate(id, readList, { new: true }).exec();
  }

  async delete(id: string): Promise<any> {
    return await this.readListModel.deleteOne({ _id: id }).exec();
  }

  async countStoriesInList(id: string): Promise<number> {
    const readList = await this.readListModel.findById(id).exec();
    return readList ? readList.stories.length : 0;
  }

  // Additional methods can be added as needed
}
